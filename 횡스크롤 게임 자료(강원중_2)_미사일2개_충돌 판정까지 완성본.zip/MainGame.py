import pygame
import background
import player
import enemy #이거적으세요 
import boss
import missile

pygame.init()

screen = pygame.display.set_mode((1920, 1080))
pygame.display.set_caption("myFirst Game")

bg = background.Background(screen)
pl = player.Player(screen)
en = enemy.Enemy(screen)  #이것도 추가
bo = boss.Boss(screen)
mi = missile.Missile(screen, bo, en)

while True:
      
      for event in pygame.event.get():
        if event.type == pygame.KEYDOWN:
          if event.key == pygame.K_q or event.key == pygame.K_ESCAPE:
            pygame.quit()
          if event.key == pygame.K_RIGHT:
            pl.moveR = True
          if event.key == pygame.K_LEFT:
            pl.moveL = True
          if event.key == pygame.K_UP:
            pl.moveU = True
          if event.key == pygame.K_DOWN:
            pl.moveD = True
          if event.key == pygame.K_a:
            pl.attack = True
            mi.missile_posU.append([pl.px, pl.py])
          if event.key == pygame.K_s:
            pl.attack = True
            mi.missile_pos.append([pl.px, pl.py])

        if event.type == pygame.KEYUP:
          if event.key == pygame.K_RIGHT:
            pl.moveR = False
          if event.key == pygame.K_LEFT:
            pl.moveL = False
          if event.key == pygame.K_UP:
            pl.moveU = False
          if event.key == pygame.K_DOWN:
            pl.moveD = False
          if event.key == pygame.K_a:
            pl.attack = False
          if event.key == pygame.K_s:
            pl.attack = False


      #배경 그리고, 갱신하기            
      bg.draw()
      bg.update()
      #플레이어 그리고, 갱신하고, 애니메이션 count 증가하기
      pl.draw()
      pl.update()
      pl.animation() #붙여주기
      #적 그리고, 갱신하기
      en.draw()
      en.update()
      #보스 그리고, 갱신하고, 애니메이션 count 증가하기
      bo.draw()
      bo.update()
      bo.animation()
      bo.bosskill()
      #미사일 그리고, 갱신하기
      mi.draw()
      mi.update()
      pygame.display.update()
