import pygame

class Player:
  def __init__(self, screen):
    self.screen = screen

    self.player_img = [ pygame.image.load("resource/standing/play_atti_standing_0.png"),
                        pygame.image.load("resource/standing/play_atti_standing_1.png"),
                        pygame.image.load("resource/standing/play_atti_standing_2.png"),
                        pygame.image.load("resource/standing/play_atti_standing_3.png")  ]

    self.playerR_img = [ pygame.image.load("resource/run_right/play_atti_run_0.png"),
                         pygame.image.load("resource/run_right/play_atti_run_1.png"),
                         pygame.image.load("resource/run_right/play_atti_run_2.png"),
                         pygame.image.load("resource/run_right/play_atti_run_3.png") ] 
                         
    self.attack_img = [pygame.image.load("resource/attack/play_atti_attack0_0.png"),
                       pygame.image.load("resource/attack/play_atti_attack0_1.png"),
                       pygame.image.load("resource/attack/play_atti_attack0_2.png"),
                       pygame.image.load("resource/attack/play_atti_attack0_3.png"),
                       pygame.image.load("resource/attack/play_atti_attack0_4.png"),
                       pygame.image.load("resource/attack/play_atti_attack0_5.png"),
                       pygame.image.load("resource/attack/play_atti_attack0_6.png"),
                       pygame.image.load("resource/attack/play_atti_attack0_7.png"),
                       pygame.image.load("resource/attack/play_atti_attack0_8.png")
                       
                       ]
    self.px = 250
    self.py = 300
    self.moveR= False
    self.moveL= False
    self.moveU=False
    self.moveD=False
    
    self.std_count = 0 #리스트 인덱스 따라가며 애니메이션 보여주기 위한 변수
    self.run_count = 0 #리스트 인덱스 따라가며 애니메이션 보여주기 위한 변수2
    
    self.attack = False 
    self.att_count = 0
    self.speed= 2
    
  def draw(self):
    if self.moveR :
        self.screen.blit(self.playerR_img[self.run_count // 60]   , (self.px, self.py))

    elif self.attack:
        self.screen.blit(self.attack_img[self.att_count // 60]   , (self.px, self.py))

    else:       
        self.screen.blit(self.player_img[self.std_count // 60]   , (self.px, self.py))
    
  def update(self):
    if self.moveR:
      self.px += self.speed
    if self.moveL:
      self.px -= self.speed
    if self.moveU:
      self.py -= self.speed
    if self.moveD:
      self.py += self.speed

  def animation(self):  ##추가한것

    self.std_count += 1 #리스트 인덱스를 증가시킨다.
    self.run_count += 1
    self.att_count += 1
    
    if self.std_count >=239 :
      self.std_count = 0

    
    if self.run_count >=239 :
      self.run_count = 0
      
    
    if self.att_count >=539 :
      self.att_count = 0
