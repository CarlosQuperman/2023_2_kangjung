import pygame

class Background:
  def __init__(self, screen):
    self.screen = screen
    self.bg_img = pygame.image.load("resource/game_background.png")
    self.bg_img2 = pygame.image.load("resource/game_background.png")
    self.x1=0
    self.y1=0
    self.x2=1920
    self.y2=0

  def draw(self):
    self.screen.blit(self.bg_img, (self.x1,self.y1))
    self.screen.blit(self.bg_img2, (self.x2,self.y2))

  def update(self):
    self.x1 -= 2
    self.x2 -= 2

    if self.x1 <= -1920:
      self.x1=1920
    if self.x2 <= -1920:
      self.x2 = 1920
